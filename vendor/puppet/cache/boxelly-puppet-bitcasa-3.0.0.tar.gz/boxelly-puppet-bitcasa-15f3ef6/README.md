Bitcasa Puppet Module for Boxen
===============================

[![Build Status](https://travis-ci.org/boxelly/puppet-bitcasa.png?branch=master)](https://travis-ci.org/boxelly/puppet-bitcasa)

Install [Bitcasa](http://www.bitcasa.com/)

## Usage

```puppet
include bitcasa
```

## Required Puppet Modules

* `boxen`
* `stdlib`
