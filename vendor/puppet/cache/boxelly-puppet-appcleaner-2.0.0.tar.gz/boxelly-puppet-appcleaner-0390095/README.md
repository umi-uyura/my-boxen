# AppCleaner Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxelly/puppet-appcleaner.png?branch=master)](https://travis-ci.org/boxelly/puppet-appcleaner)

Install [AppCleaner](http://www.freemacsoft.net/appcleaner/).

## Usage

```puppet
include appcleaner
```

## Required Puppet Modules

* `boxen`
* `stdlib`
